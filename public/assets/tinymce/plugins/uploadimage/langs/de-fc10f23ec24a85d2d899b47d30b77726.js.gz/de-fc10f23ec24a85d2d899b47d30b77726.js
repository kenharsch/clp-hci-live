tinyMCE.addI18n('de', {
  'Insert an image from your computer': 'Bild vom Computer einfügen',
  'Insert image': 'Bild einfügen',
  'Choose an image':  "Bild auswählen",
  'You must choose a file': "Datei auswählen",
  'Got a bad response from the server': "Ungültige Antwort vom Server",
  "Didn't get a response from the server": "Server antwortet nicht",
  'Insert': "Einfügen",
  'Cancel': "Abbrechen",
  'Image description': "Bildbeschreibung"
});
