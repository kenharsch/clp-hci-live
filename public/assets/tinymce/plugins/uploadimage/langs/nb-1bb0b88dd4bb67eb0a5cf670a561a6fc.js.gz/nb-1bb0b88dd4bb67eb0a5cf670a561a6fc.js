tinyMCE.addI18n('nb', {
  'Insert an image from your computer': 'Sett inn et bilde fra datamaskinen',
  'Insert image': "Sett inn bilde",
  'Choose an image': "Velg et bilde",
  'You must choose a file': "Du m\u00e5 velge en fil",
  'Got a bad response from the server': "Fikk et ugyldig svar fra serveren",
  "Didn't get a response from the server": "Fikk ikke svar fra serveren",
  'Insert': "Sett inn",
  'Cancel': "Avbryt",
  'Image description': "Alternativ tekst for bilde",
});
